<?php session_start();
	require_once('../config.php');
	if(!isset($_SESSION['userinfo'])){
		header("Location: login.php");
	} 
?>