<?php session_start();
	require_once('../config.php');
	if(!isset($_SESSION['userinfo'])){ //username same hote hoby
		header("Location: login.php");
	}else{
		echo '<meta http-equiv="refresh" content="1; url=http:../index.php">'; 
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Admin Index Page</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="main-conternt">
					<h2>Welcome to Adminal Panel</h2>
					<p>Hi, <?php echo $_SESSION['userinfo']; ?></p>
					<a class="btn btn-lg btn-success" href="logout.php">Logout</a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>