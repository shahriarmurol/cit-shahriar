<?php session_start(); 
	if(isset($_SESSION['userinfo'])){
		session_destroy();
		header("Location: login.php");
	}


?>
