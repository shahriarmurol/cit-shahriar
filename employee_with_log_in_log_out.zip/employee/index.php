<?php session_start();
    require_once('config.php');
    if(!isset($_SESSION['userinfo'])){
      header("Location: admin/login.php");
    }

?>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <title>Student Registration</title>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- all css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
    <!-- all content goes here -->
    <div class="wrap">
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-md-offset-1">
        <h1>Manage All Employee Information 
          <span class="pull-right">
            <a href="insert.php" class="btn btn-success">Add Employee</a>
            <a href="admin/logout.php" class="btn btn-success">Logout</a>
            </span>
        </h1>
            <table class="table table-striped">
              <tr>
                <th>Sr No.</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Designation</th>
                <th>Action</th>
              </tr>
              <?php 
                $sr=1;
                $slt="SELECT * FROM employee_info NATURAL JOIN employee_desn ORDER BY id DESC LIMIT 0,10";
                $qre=mysqli_query($dbc,$slt);
                while($info=mysqli_fetch_array($qre)){  ?>
                    <tr>
                      <td><?= $sr++; ?></td>
                      <td><?= $info['name']; ?></td>
                      <td><?= substr($info['phone'],0,5); ?>...</td>
                      <td><?= $info['email']; ?></td>
                      <td><?= $info['desn_name']; ?></td>
                      <td>
                        <a href="view.php?id=<?= $info['id']; ?>"><i class="fa fa-eye fa-2x"></i></a>
                        <a href="update.php?update_id=<?= $info['id']; ?>"><i class="fa fa-pencil-square-o fa-2x"></i></a>
                        <a href="delete.php?delete_id=<?= $info['id']; ?>"><i class="fa fa-trash fa-2x"></i></a>
                      </td>
                    </tr>
                <?php    }
              ?>
            </table>
          </div>

        </div>
      </div>
    </div>
    <!-- all js -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>
