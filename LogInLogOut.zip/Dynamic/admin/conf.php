<?php
	$HOST_NAME = "localhost";
	$HOST_USER = "root";
	$HOST_PASS = "";
	$HOT_DB = "dynamic";
	$HOST_DBC = mysqli_connect($HOST_NAME, $HOST_USER, $HOST_PASS, $HOT_DB);

	if(!$HOST_DBC){
		echo "Database Connection Error!";
	}
	//echo "success";
?>