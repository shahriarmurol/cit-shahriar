<?php session_start();
	require_once('../includes/config.php'); // db connection

	if(!empty($_POST)){
		$name = $_POST['user_name'];
		$pass = $_POST['pass_word'];
		//echo $name." ".$pass;

		//query
		$slt = "SELECT * FROM cit_user WHERE username='$name' AND password='$pass'"; // where condition=value
		//database ar username jodi Form ar user_name hoy and database ar password jodi form ar pass_word 
	    $qre=mysqli_query($dbc,$slt);
	    if(mysqli_fetch_array($qre)){
	    	$_SESSION['username'] = $_POST['user_name'];//db user name ar modd file ar value assaign
	    	header("Location: index.php");
	    }else{
	    	echo "Hoi nai";
	    }

	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Admin Panel:: Home</title>
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
	<h2 class="text-center" style="margin-top: 60px;">Welcome To Admin Panel.</h2>
	<div class="login" style="margin-top:30px;">
		<div class="container-fluid">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<form style="margin-top: 30px;" action="" method="post">
							<div class="form-group">
								<label for="username">Username</label>
								<input type="text" name="user_name" id="username" class="form-control">
							</div>
							<div class="form-group">
								<label for="password">Password</label>
								<input type="text" name="pass_word" id="password" class="form-control">
							</div>
							<input class="btn btn-block btn-success" type="submit" value="Login" name="" />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	
</body>
</html>