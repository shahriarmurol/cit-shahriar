<?php
	require_once('functions/function.php');
	get_header();
	get_part('service_page.php');
	right_sidebar();
	get_footer();
?>				