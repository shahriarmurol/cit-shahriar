<?php 
    //print_r($_SERVER); //server all info
    //echo($_SERVER['PHP_SELF']); // current page address
    //$link = explode('/', $_SERVER['PHP_SELF']);
    //print_r($link); // array result with index
    $link = explode('/', $_SERVER['PHP_SELF']);
    $page =$link[2]; //page address
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Arcana by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>
		<div id="page-wrapper">
            <div id="header">
                    <nav id="nav">
                        <ul>
                            <li <?php if($page == 'index.php'){echo 'class="current"';} ?> ><a href="index.php">Home</a></li>
                            <li <?php if($page == 'about.php'){echo 'class="current"';} ?>><a href="about.php">About Us</a></li>
                            <li <?php if($page == 'gallery.php'){echo 'class="current"';} ?>><a href="gallery.php">Gallery</a></li>
                            <li <?php if($page == 'service.php'){echo 'class="current"';} ?>><a href="service.php">Our Service</a></li>
                            <li <?php if($page == 'contact.php'){echo 'class="current"';} ?>><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </nav>
                </div>
