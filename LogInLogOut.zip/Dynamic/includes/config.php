<?php
	$host = "localhost";
	$username = "root";
	$password = "";
	$db = "dynamic";
	$dbc = mysqli_connect($host, $username, $password, $db);
	if(!$dbc){
		echo "Database Connection Error!";
	}
	//echo "success";
?>