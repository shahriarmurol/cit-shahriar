jQuery(document).ready(function($)){
	$('#nav ul li').click(function($)){
		$('#nav ul li').removeClass('current');
		$(this).addClass('current');
	});
});
