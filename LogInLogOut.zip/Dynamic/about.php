<?php
	require_once('functions/function.php');
	get_header();
	left_sidebar();
	get_part('about_page.php');
	get_footer();
?>				