<?php session_start(); 
	require_once('../function/functions.php');
	if(isLogged()){
		session_destroy();
		header("Location: login.php");
	}

	// if(isset($_SESSION['user'])){
	// 	session_destroy();
	// 	header("Location: login.php");
	// }
?>
