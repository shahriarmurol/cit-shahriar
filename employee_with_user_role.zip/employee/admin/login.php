<?php session_start();
	require_once('../config.php');
	if(!empty($_POST)){
		$name = $_POST['userName'];
		$pass = $_POST['passWord'];
		//query
		$slt = "SELECT * FROM user WHERE user_username='$name' AND user_pass='$pass'";
		$qre=mysqli_query($dbc,$slt);
		$result = mysqli_fetch_array($qre);
		if($result){
			$_SESSION['user'] = $result['user_username']; //user info te db theke username asaign
			$_SESSION['roleid'] = $result['role_id']; //user roleid = db role_id
			header("Location:index.php");
		}else{
			echo "Please Check Username & Password";
		}
	}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Admin Index Page</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>
<h2 class="text-center" style="margin-top: 60px;">Welcome To Admin Panel.</h2>
	<div class="login" style="margin-top:30px;">
		<div class="container-fluid">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<form style="margin-top: 30px;" action="" method="post">
							<div class="form-group">
								<label for="username">Username</label>
								<input type="text" name="userName" id="username" class="form-control">
							</div>
							<div class="form-group">
								<label for="password">Password</label>
								<input type="text" name="passWord" id="password" class="form-control">
							</div>
							<input class="btn btn-block btn-success" type="submit" value="Login" name="" />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	
</body>
</html>