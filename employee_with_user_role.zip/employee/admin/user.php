<?php session_start();
	require_once('../config.php');
	require_once('../function/functions.php');
	needLogged();
	// if(!isset($_SESSION['user'])){
	// 	header("Location: login.php");
	// } 
?>