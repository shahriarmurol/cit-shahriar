<?php session_start();
    require_once('config.php');
    require_once('function/functions.php');
    needLogged();
    //only see super admin
    if($_SESSION['roleid']<=3 ){ // <= 3 maen super admin admin porjonto so kaj korbe, author ar role nice(no delete)
      //condition for super admin start
?>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <title>Student Registration</title>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1"> 
        <!-- all css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
    <!-- all content goes here -->
    <div class="wrap">
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-md-offset-1">
        <h1>Manage All Employee Information 
          <span class="pull-right">
            <a href="insert.php" class="btn btn-success">Add Employee</a>
            <a href="admin/logout.php" class="btn btn-success">Logout</a>
            </span>
        </h1>
            <table class="table table-striped">
              <tr>
                <th>Sr No.</th>
                <th>Name</th>  
                <th>Phone</th>
                <th>Email</th>
                <th>Designation</th>
                <th>Action</th>
              </tr>
              <?php
                //for search 
                $search = $_POST['search'];
                //search end
                $sr=1;
                $slt="SELECT * FROM employee_info NATURAL JOIN employee_desn WHERE name='$search' ";
                $qre=mysqli_query($dbc,$slt);
                while($info=mysqli_fetch_array($qre)){  ?>
                    <tr>
                      <td><?= $sr++; ?></td>
                      <td><?= $info['name']; ?></td>
                      <td><?= substr($info['phone'],0,5); ?>...</td>
                      <td><?= $info['email']; ?></td>
                      <td><?= $info['desn_name']; ?></td>
                      <td>
                        <a href="view.php?id=<?= $info['id']; ?>"><i class="fa fa-eye fa-2x"></i></a>
                        <a href="update.php?update_id=<?= $info['id']; ?>"><i class="fa fa-pencil-square-o fa-2x"></i></a>

                        <?php 
                          if($_SESSION['roleid'] <=2 ){ ?>
                        <a href="delete.php?delete_id=<?= $info['id']; ?>"><i class="fa fa-trash fa-2x"></i></a>
                        <?php 
                           }//author delete korte parbe na
                        ?>

                      </td>
                    </tr>
                <?php    }
              ?>
            </table>
          </div>

        </div>
      </div>
    </div>
    <!-- all js -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>
<?php 
  }else{
    echo "Access Denied!"; //super admin condition end
  }
?>