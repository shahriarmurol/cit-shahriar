<?php session_start();
    require_once('./config.php'); // database connection file
    require_once('function/functions.php');
    needLogged();
    //catch data
    //!empty($_POST)
    if(isset($_POST['formAdd'])){
      $name= $_POST['name'];
      $phone= $_POST['phone'];
      $email= $_POST['email'];
      $desn_id= $_POST['desn_id'];
      $dist_id= $_POST['dist_id'];
      $edu_id= $_POST['edu_id'];
      $picture= $_FILES['picture'];
      $picture_name ='Stuent-'.time().'-'.rand(1000,100000).'.'.pathinfo($picture['name'],PATHINFO_EXTENS);
      //mysql query
      if(!empty($name)){
        $insert ="INSERT INTO employee_info(name, phone, email, desn_id, dist_id, edu_id, photo) VALUES('$name', '$phone', '$email', '$desn_id', '$dist_id', '$edu_id', '$picture_name')";
        $insert_query=mysqli_query($dbc, $insert); //insert query
        //innser if else or nested if else
        if($insert_query){
            move_uploaded_file($picture['tmp_name'],'img/'.$picture_name);
            echo "Data has ben Inserted Successfullt";
            header("Location:index.php");
        }else{
          echo "Data Insert Error!";
        }//End of the inner if else 
      }else{
        echo "Name Please";  
    }

  }
?>
<!doctype html>
<html  lang="en-US">
    <head>
        <title>Employee Registration</title>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- all css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
    <!-- all content goes here -->
    <div class="wrap">
      <div class="container">
        <div class="row">
          <h1 class="text-center">Employee Registration Form</h1>
          <div class="col-md-6 col-md-offset-3">
          <!-- form -->
              <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" id="name" name="name" class="form-control" />
                </div>
                <div class="form-group">
                  <label for="phone">Phone</label>
                  <input type="text" name="phone" id="phone"  class="form-control" />
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="text" name="email" id="email" class="form-control" />
                </div>
                <div class="from-group">
                  <label for="desn_id">Designation</label>
                  <select name="desn_id" id="desn_id" class="form-control">
                    <option value="" selected>Select Designation</option>
                    <?php 
                      $slt="SELECT * FROM employee_desn ORDER BY desn_name DESC";
                      $qr=mysqli_query($dbc,$slt);
                      while($info=mysqli_fetch_array($qr)){  ?>
                        <option value="<?= $info['desn_id']; ?>"> <?= $info['desn_name']; ?> </option>
                    <?php    }
                    ?>
                  </select>
                </div>
                <div class="from-group">
                  <label for="dist_id">District</label>
                  <select class="form-control" name="dist_id" id="dist_id">
                    <option value="" selected>Select District</option>
                     <?php 
                      $slt="SELECT * FROM employee_dist ORDER BY dist_name DESC";
                      $qr=mysqli_query($dbc,$slt);
                      while($info2=mysqli_fetch_array($qr)){  ?>
                        <option value="<?= $info2['dist_id']; ?>"> <?= $info2['dist_name']; ?> </option>
                    <?php   }
                    ?>
                  </select>
                </div>
                <div class="from-group">
                  <label for="edu_id">Education</label>
                  <select class="form-control" name="edu_id" id="edu_id">
                    <option value="" selected>Select Education</option>
                     <?php 
                      $slt="SELECT * FROM employee_edu ORDER BY edu_name DESC";
                      $qr=mysqli_query($dbc,$slt);
                      while($info3=mysqli_fetch_array($qr)){  ?>
                        <option value="<?= $info3['edu_id']; ?>"> <?= $info3['edu_name']; ?> </option>
                    <?php   }
                    ?>
                  </select>
                </div>
               <div class="form-group">
                 <label for="picture">Picture</label>
                 <input type="file" name="picture" id="picture" />
               </div> 
               <button type="submit" name="formAdd" class="btn btn-success">Add Employee</button>
                <a href="admin/logout.php" class="btn btn-success pull-right">Logout</a>
              </form>
              <!-- /form -->
          </div>
        </div>
      </div>
    </div>
    <!-- all js -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>
