<?php 
    require_once('config.php');

    $id = $_GET['e'];
    $sele = "SELECT * FROM cit_student where stu_id='$id' ";
    $qu = mysqli_query($db_connect, $sele);
    $data = mysqli_fetch_array($qu);
    //update 
    if(!empty($_POST)){
         //catch data
        $name = $_POST['name']; // name is input field name
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $roll = $_POST['roll'];
        $dept = $_POST['department'];
        $session = $_POST['session'];
        if(!empty($name)){
    $update ="UPDATE cit_student SET stu_name='$name',stu_email='$email', stu_phone='$phone',stu_roll = '$roll', dept_id='$dept', stu_session='$session' where stu_id='$id' ";
            if(mysqli_query($db_connect,$update)){
                echo "update hoice";
                header('Location: manage.php');
            }else{
                echo "update hoy nai";
            }
        }else{
            echo "Please Enter Student info!";
        }
    }
?>
<?php
    require_once('functions/function.php');
    get_header();
?>
            <div class="body_part">
                <h2>Student Registration</h2>
                <form action="" method="post">
                    <table class="reg_table" border="0" cellpadding="0" cellspacing="10">
                        <tr>
                            <td>Student Name</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="name" value="<?= $data['stu_name'];?>" id="" class="input_field"/>
                            </td>
                        </tr>
                         <tr>
                            <td>Student Email</td>
                            <td>:</td>
                            <td>
                                <input type="email" name="email" value="<?= $data['stu_email'];?>" id="" class="input_field"/>
                            </td>
                        </tr>                   
                        <tr>
                            <td>Student Phone</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="phone" value="<?= $data['stu_phone'];?>" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td>Student Roll</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="roll" value="<?= $data['stu_roll'];?>" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td>Student Department</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="department" value="<?= $data['dept_id'];?>" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td>Student Session</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="session" value="<?= $data['stu_session'];?>" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>
                                <input type="submit" value="UPDATE" id="" class="submit"/>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
<?php 
    require_once('functions/function.php');
    get_footer();
?>