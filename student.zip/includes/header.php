
<!DOCTYPE html>
<html>
	<head>
    	<title>Creative :: Student Registration</title>
        <link type="text/css" rel="stylesheet" href="css/font-awesome.min.css"/>
        <link type="text/css" rel="stylesheet" href="css/style.css" />
    </head>
    <body>
    	<div class="wrapper">
        	<div class="header">
            </div>