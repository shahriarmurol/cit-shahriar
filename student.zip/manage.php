<?php 
  require_once('config.php');
  require_once('functions/function.php');
  get_header();
?>
            <div class="body_part">
                <h2>Manage All Student</h2>
                <form action="" method="post">
                    <table width="100%" class="table_manage" align="center" border="0" cellpadding="10" cellspacing="0">
                       <tr>
                       		<th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Deaprtment</th>
                            <th>Manage</th>
                       </tr>
                       <?php 
                         $sele = "SELECT * FROM cit_student ORDER BY stu_id DESC";//all data
                         $que = mysqli_query($db_connect, $sele);
                         while($data=mysqli_fetch_array($que)){
                          ?>
                       <tr>
                       		  <td><?= $data['stu_id'] ?></td>
                            <td><?= $data['stu_name'] ?></td>
                            <td><?= $data['stu_email'] ?></td>
                            <td><?= $data['stu_phone'] ?></td>
                            <td><?= $data['dept_id'] ?></td>
                            <td>
                              <a href="view.php?v=<?= $data['stu_id'];?>" title="View"><i class="fa fa-plus-square"></i></a>
                              <a href="edit.php?e=<?= $data['stu_id'];?>" title="Edit"><i class="fa fa-pencil-square-o"></i></a>
                              <a href="delete.php?d=<?= $data['stu_id'];?>" title="Delete"><i class="fa fa-trash"></i></a>
                            </td>
                            <td><input type="hidden"><?php $data['stu_id']; ?></td>
                       </tr>
                          <?php
                         }
                       ?>
                    </table>
                </form>
            </div>
<?php 
  require_once('functions/function.php');
  get_header();
?>
