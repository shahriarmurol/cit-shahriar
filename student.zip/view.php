<?php 
    require_once('config.php');
    require_once('functions/function.php');
    get_header();
    $id = $_GET['v'];
    $sel = "SELECT * FROM cit_student WHERE stu_id='$id' "; //data view with id
    $q = mysqli_query($db_connect,$sel);
    $info = mysqli_fetch_array($q); //for single data
?>     
            <div class="body_part">
                <h2>Student Personal Information</h2>
                <form action="" method="post">
                    <table class="reg_table" border="0" cellpadding="0" cellspacing="10">
                        <tr>
                            <td>Student Name</td>
                            <td>:</td>
                            <td><?= $info['stu_name']; ?></td>
                        </tr>
                         <tr>
                            <td>Student Email</td>
                            <td>:</td>
                            <td><?= $info['stu_email']; ?></td>
                        </tr>                   
                        <tr>
                            <td>Student Phone</td>
                            <td>:</td>
                            <td><?= $info['stu_phone']; ?></td>
                        </tr>
                        <tr>
                            <td>Student Roll</td>
                            <td>:</td>
                            <td><?= $info['stu_roll']; ?></td>
                        </tr>
                        <tr>
                            <td>Student Department</td>
                            <td>:</td>
                            <td><?= $info['dept_id']; ?></td>
                        </tr>
                        <tr>
                            <td>Student Session</td>
                            <td>:</td>
                            <td><?= $info['stu_session']; ?></td> 
                        </tr>
                    </table>
                </form>
            </div>
<?php 
    require_once('functions/function.php');
    get_footer();
?>
