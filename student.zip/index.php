<?php 
    require_once('config.php');

    if(!empty($_POST)){
        //catch data
        $name = $_POST['name'];
        $email = $_POST['email'];
        $cell = $_POST['phone'];
        $roll = $_POST['roll'];
        $dept = $_POST['department'];
        $session = $_POST['session'];      

      
        // insert quirey 
        if(isset($_POST['submit'])){
                //validation
                $phone_limit = strlen($cell);
                if($phone_limit <= 5 ){
                    //echo "valid phone number<br>";
                    //insert
                    $insert = "INSERT INTO cit_student(stu_id,stu_name,stu_email,stu_phone,stu_roll,dept_id,stu_session)
                    VALUES('','$name','$email','$cell','$roll','$dept','$session')";

                    if(mysqli_query($db_connect, $insert)){
                        echo "Hoice";
                    }else{
                        echo "Hoi Nai";
                    }//inner if else
                }else{
                    echo "Phone number must be in 5 digit.<br>";
                }
            //insert

        }else{
            echo "Please Enter Student Name!";
        }     
    }
?>            
<?php  
    require_once('functions/function.php'); 
    get_header();
?>
            <div class="body_part">
                <h2>Student Registration</h2>
                <a href="manage.php">Manage Page</a>
                <form action="" method="post">
                    <table class="reg_table" border="0" cellpadding="0" cellspacing="10">
                        <tr>
                            <td>Student Name</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="name" id="" class="input_field"/>
                            </td>
                        </tr>
                         <tr>
                            <td>Student Email</td>
                            <td>:</td>
                            <td>
                                <input type="email" name="email" id="" class="input_field"/>
                            </td>
                        </tr>                   
                        <tr>
                            <td>Student Phone</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="phone" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td>Student Roll</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="roll" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td>Student Department</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="department" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td>Student Session</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="session" id="" class="input_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>
                                <input type="submit"  value="REGISTRATION" id="" class="submit" name="submit" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
<?php 
    require_once('functions/function.php');
    get_footer();
?>