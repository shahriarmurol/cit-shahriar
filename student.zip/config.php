<?php 
	$HOST = "localhost";
	$USER = "root";
	$PASSWORD = "";
	$DB = "student";
	$db_connect = mysqli_connect($HOST,$USER,$PASSWORD,$DB);
	if(!$db_connect){
		echo "Database Connection Error!";
	}
?>