<?php
	class Page{
		
	}