<?php 
        require_once 'function/Manage.php';
        $objPageContents->get_header();
        $objPageContents->get_theme_part('portfolio-page-content');
        $objPageContents->get_footer();
