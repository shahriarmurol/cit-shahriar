<?php
    require_once('classes/PageContents.php');
    //object 
    $objPageContents = new PageContent(); // object
