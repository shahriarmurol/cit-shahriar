<?php 
        //include requirement page
        require_once 'function/Manage.php';
        $objPageContents->get_header();
        $objPageContents->get_slider();
        $objPageContents->get_service();
        $objPageContents->get_footer();
?>

	