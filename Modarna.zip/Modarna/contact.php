<?php 

    require_once 'function/Manage.php';
        $objPageContents->get_header();
        $objPageContents->get_theme_part('contact-nav');
        $objPageContents->get_theme_part('contact-body');
	$objPageContents->get_footer();
