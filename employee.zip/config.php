<?php 
	$host="localhost";
	$username="root";
	$password="";
	$db="employee";
	$dbc=mysqli_connect($host, $username, $password, $db);
	if(!$dbc){
		echo "DB Connection Error!";
	}
	//echo "DB Success";
?>