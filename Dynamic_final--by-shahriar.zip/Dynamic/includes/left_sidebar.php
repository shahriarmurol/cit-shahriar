<section class="wrapper style1">
    <div class="container">
        <div class="row 200%">
            <div class="4u 12u(narrower)">
                <div id="sidebar">
                        <section>
                            <h3>Just a Subheading</h3>
                            <p>Phasellus quam turpis, feugiat sit amet ornare in, hendrerit in lectus.
                            Praesent semper mod quis eget mi. Etiam eu ante risus. Aliquam erat volutpat.
                            Aliquam luctus et mattis lectus sit amet pulvinar. Nam turpis et nisi etiam.</p>
                            <footer>
                                <a href="#" class="button">Continue Reading</a>
                            </footer>
                        </section>

                        <section>
                            <h3>Another Subheading</h3>
                            <ul class="links">
                                <li><a href="#">Amet turpis, feugiat et sit amet</a></li>
                                <li><a href="#">Ornare in hendrerit in lectus</a></li>
                                <li><a href="#">Semper mod quis eget mi dolore</a></li>
                                <li><a href="#">Consequat etiam lorem phasellus</a></li>
                                <li><a href="#">Amet turpis, feugiat et sit amet</a></li>
                                <li><a href="#">Semper mod quisturpis nisi</a></li>
                            </ul>
                            <footer>
                                <a href="#" class="button">More Random Links</a>
                            </footer>
                        </section>

                </div>
            </div>