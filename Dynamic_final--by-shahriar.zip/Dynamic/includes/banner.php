<section id="banner">
    <header>
        <h2>Arcana: <em>A responsive site template freebie by <a href="#">HTML5 UP</a></em></h2>
        <a href="#" class="button">Learn More</a>
    </header>
</section>