<?php 
    require_once('config.php');
    require_once('function/functions.php');
    needLogged();
	$id = $_REQUEST['delete_id'];
	$slt = "DELETE FROM employee_info WHERE id='$id'";
	$qre = mysqli_query($dbc, $slt);
	header("Location: index.php"); 
?>