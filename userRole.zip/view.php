<?php 
  require_once('config.php');
  require_once('function/functions.php');
  needLogged();
  $id = $_REQUEST['id'];
  $slt="SELECT * FROM employee_info WHERE id='$id' ";
  $qre=mysqli_query($dbc, $slt);
  $info=mysqli_fetch_array($qre);
?>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <title>Employee Infomations</title>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- all css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
    <!-- all content goes here -->
    <div class="wrap">
      <div class="container">
        <div class="row">
          <h1 class="text-center">Employee Information</h1>
          <div class="col-md-8 col-md-offset-2">
          <!-- form -->
          <table class="table table-hover table-striped">
            <tr>
              <td>Name</td>
              <td><?= $info['name']; ?></td>
            </tr>
            <tr>
              <td>Phone</td>
              <td><?= $info['phone']; ?></td>
            </tr>
            <tr>
              <td>Email</td>
              <td><?= $info['email']; ?></td>
            </tr>
            <tr>
              <td>Designation</td>
              <?php 
                //$id = $_REQUEST['id'];
                $slt="SELECT * FROM employee_info NATURAL JOIN employee_desn WHERE id='$id' ";
                $qre=mysqli_query($dbc, $slt);
                $info=mysqli_fetch_array($qre); 
                  ?>
                  <td><?= $info['desn_name']; ?></td> 
                <?php
              ?>
            </tr>
            <tr>
              <td>District</td>
               <?php 
                //$id = $_REQUEST['id'];
                $slt="SELECT * FROM employee_info NATURAL JOIN employee_dist WHERE id='$id' ";
                $qre=mysqli_query($dbc, $slt);
                $info=mysqli_fetch_array($qre); 
                  ?>
                  <td><?= $info['dist_name']; ?></td> 
                <?php
              ?>
            </tr>
            <tr>
              <td>Education</td>
                 <?php 
                //$id = $_REQUEST['id'];
                $slt="SELECT * FROM employee_info NATURAL JOIN employee_edu WHERE id='$id' ";
                $qre=mysqli_query($dbc, $slt);
                $info=mysqli_fetch_array($qre); 
                  ?>
                  <td><?= $info['edu_name']; ?></td> 
                <?php
              ?>
            </tr>
            <tr>
              <td>Profile Pricture</td>
              <td>
                <img width="100px" src="img/<?= $info['photo']; ?>" alt="">
              </td>
            </tr>
          </table>
         
              <!-- /form -->
          </div>
        </div>
      </div>
    </div>
    <!-- all js -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>
