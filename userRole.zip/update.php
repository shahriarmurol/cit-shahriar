<?php 
  require_once('config.php');
  require_once('function/functions.php');
  needLogged();
  //for set value in input field
  $id = $_REQUEST['update_id'];
  $slt = "SELECT * FROM employee_info WHERE id='$id' ";
  $qre = mysqli_query($dbc, $slt);
  $info=mysqli_fetch_array($qre);
  // End for set value in input field
  //update start
  if(isset($_POST['formUpdate'])){
    //$ID=$_REQUEST['update_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $Email = $_POST['Email'];
    $desn_id = $_POST['desn_id'];
    $dist_id = $_POST['dist_id'];
    $edu_id = $_POST['edu_id'];
    $picture = $_POST['picture'];
    $picture_name = 'Employee-'.time().'-'.rand(1000,10000).'.'.pathinfo($picture['name'], PATHINFO_EXTENSION);

    if(!empty($name)){
      $update = "UPDATE employee_info SET name='$name', phone='$phone', email='$email', desn_id='$desn_id', dist_id='$dist_id', edu_id='$edu_id', photo='$picture_name' WHERE id='$id' ";

        $update_query = mysqli_query($dbc,$update);
        if($update_query){
          move_uploaded_file($picture['tmp_name'],'img/'.$picture_name);
          echo "Updated Successfully";
          header("Location: index.php");
        }else{
          echo "Update Error!";
        }
    }else{
      echo "Name please!";
    }

  }

  //update end
?>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <title>Update Student Information</title>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- all css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
    <!-- all content goes here -->
    <div class="wrap">
      <div class="container">
        <div class="row">
          <h1 class="text-center">Update Student Information</h1>
          <div class="col-md-6 col-md-offset-3">
          <!-- form -->
 <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" id="name" name="name" value="<?= $info['name']; ?>" class="form-control" />
                </div>
                <div class="form-group">
                  <label for="phone">Phone</label>
                  <input type="text" id="phone" name="phone" value="<?= $info['phone']; ?>" class="form-control" />
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="text" id="email" name="email" value="<?= $info['email']; ?>" class="form-control" />
                </div>
                <div class="from-group">
                  <label for="desn_id">Designation</label>
                  <select class="form-control" name="desn_id" id="desn_id">
                    <?php 
                    $slt = "SELECT * FROM employee_desn ORDER BY desn_name DESC";
                    $qre = mysqli_query($dbc, $slt);
                    while($desn=mysqli_fetch_array($qre)){
                      ?>
                         <option value="<?= $desn['desn_id']; ?>"><?= $desn['desn_name']; ?></option>
                      <?php  
                    }
                    ?>
                  </select>
                </div>
                <div class="from-group">
                  <label for="dist_id">District</label>
                  <select class="form-control" name="dist_id" id="dist_id">
                    <?php 
                    $slt = "SELECT * FROM employee_dist ORDER BY dist_name DESC";
                    $qre = mysqli_query($dbc, $slt);
                    while($dist=mysqli_fetch_array($qre)){
                      ?>
                         <option value="<?= $dist['dist_id']; ?>"><?= $dist['dist_name']; ?></option>
                      <?php  
                    }
                    ?>
                  </select>
                </div>
                <div class="from-group">
                  <label for="edu_id">Education</label>
                  <select class="form-control" name="edu_id" id="edu_id">
                    <?php 
                    $slt = "SELECT * FROM employee_edu ORDER BY edu_name DESC";
                    $qre = mysqli_query($dbc, $slt);
                    while($edu=mysqli_fetch_array($qre)){
                      ?>
                         <option value="<?= $edu['edu_id']; ?>"><?= $edu['edu_name']; ?></option>
                      <?php  
                    }
                    ?>
                  </select>
                </div>
              
               <div class="form-group">
                 <label for="picture">Picture</label>
                 <input type="file" id="picture" name="picture" />
               </div> 
               <button type="submit" name="formUpdate" class="btn btn-success">Update</button>
              </form>
              <!-- /form -->
          </div>
        </div>
      </div>
    </div>
    <!-- all js -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </body>
</html>
