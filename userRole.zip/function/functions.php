<?php
	function isLogged(){ // keo log in korlo kina
		return $_SESSION['user']? true:false;  // user log in korce kina
	}
	function needLogged(){
		if(!isLogged()){
			header("Location:admin/login.php");
			exit();//Output a message and terminate the current script
		}
	}